import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

public class Solver {

    private boolean isSolvable;
    private List<Board> minNumberStep = new ArrayList<>();

    public Solver(Board initialBoard) {
        MinPQ<SolverStep> solverSteps = new MinPQ<>(new SolverStepComparator());
        MinPQ<SolverStep> solverStepsTwin = new MinPQ<>(new SolverStepComparator());
        solverSteps.insert(new SolverStep(initialBoard, 0, null));
        solverStepsTwin.insert(new SolverStep(initialBoard.twin(), 0, null));

        SolverStep step;
        while (!solverSteps.min().board.isGoal() && !solverStepsTwin.min().board.isGoal()) {
            SolverStep solverStep = solverSteps.delMin();

            for (Board board : solverStep.board.neighbors()) {
                if (!isAlreadyInSolutionPath(board, solverStep)) {
                    solverSteps.insert(new SolverStep(board, solverStep.move + 1, solverStep));
                }
            }

            SolverStep solverStepTwin = solverStepsTwin.delMin();
            for (Board board : solverStepTwin.board.neighbors()) {
                if (!isAlreadyInSolutionPath(board, solverStepTwin)) {
                    solverStepsTwin.insert(new SolverStep(board, solverStepTwin.move + 1, solverStepTwin));
                }
            }

        }

        step = solverSteps.delMin();
        isSolvable = step.board.isGoal();

        minNumberStep.add(0, step.getBoard());

        while ((step = step.getPrevStep()) != null) {
            minNumberStep.add(0, step.getBoard());
        }

    }

    public boolean isSolvable() {
        return isSolvable;
    }

    public int moves() {
        return minNumberStep.size() - 1;
    }

    public Iterable<Board> solution() {

        Iterable<Board> iterable;

        if (isSolvable) {
            iterable = new Iterable<Board>() {

                @Override
                public Iterator<Board> iterator() {
                    return new SolutionIterator();
                }

            };
        } else {
            iterable = null;
        }
        return iterable;
    }

    private class SolutionIterator implements Iterator<Board> {

        int index = 0;

        @Override
        public boolean hasNext() {
            return index < minNumberStep.size();
        }

        @Override
        public Board next() {
            if (index == minNumberStep.size()) {
                throw new NoSuchElementException("index is greater than size of the min array");
            }
            return minNumberStep.get(index++);
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("not supported to remove a board from solution");
        }

    }

    private boolean isAlreadyInSolutionPath(Board board, Solver.SolverStep solverStep) {
        while ((solverStep = solverStep.getPrevStep()) != null) {
            if (solverStep.board.equals(board))
                return true;
        }
        return false;
    }

    private static class SolverStep {
        private Board board;
        private int move;
        private SolverStep prevStep;

        public SolverStep(Board board, int move, SolverStep prevStep) {
            this.board = board;
            this.move = move;
            this.prevStep = prevStep;
        }

        public Board getBoard() {
            return board;
        }

        public int getMove() {
            return move;
        }

        public SolverStep getPrevStep() {
            return prevStep;
        }

        public int getPriority() {
            return board.manhattan() + move;
        }

    }

    private static class SolverStepComparator implements Comparator<SolverStep> {

        @Override
        public int compare(Solver.SolverStep o1, Solver.SolverStep o2) {
            return o1.getPriority() - o2.getPriority();
        }

    }

    public static void main(String[] args) {

        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
            System.out.println(solver.moves());
        }

    }

}
